browser = "chrome"
url = "https://www.redbus.in/bus-tickets/"

chrome_driver = "C:\\drivers\\chromedriver_win32\\chromedriver.exe"
firefox_driver = "C:\\drivers\\chromedriver_win32\\geckodriver.exe"