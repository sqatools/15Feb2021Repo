url = 'https://www.dummyticket.com/dummy-ticket-for-visa-application/'

username = 'Vikas'
surname = 'sharma'

birth_date = '28'